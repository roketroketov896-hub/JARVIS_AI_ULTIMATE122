# JARVIS Backend — отдельный сервер (не Replit)

Этот архив содержит backend JARVIS для развёртывания на Render. Он не является готовым публичным сервером до публикации в аккаунте хостинга.

## Что важно
- Backend работает отдельно от сайта админ-панели Cloudflare Pages.
- Админка и Android-приложение должны использовать один и тот же URL этого backend.
- Данные сохраняются на постоянном диске `/data`.
- Админ API закрыт: `ADMIN_MODE=google`, администратор задаётся в `ADMIN_EMAILS`.
- Не переключайте `ADMIN_MODE` на `open` для публичного сайта.

## Переменные Render
Blueprint `render.yaml` задаёт:
- `GOOGLE_WEB_CLIENT_ID` — Web Client ID Google из проекта JARVIS;
- `ADMIN_EMAILS` — Google-почта администратора;
- `CONFIG_SECRET` — генерируется Render автоматически;
- `ADMIN_MODE=google` — защищённый вход администратора;
- `DATA_FILE=/data/jarvis.json` — файл на постоянном диске;
- `OPENROUTER_API_KEY` — необязательный стартовый ключ ИИ.

## Публикация
1. Создайте GitHub-репозиторий и загрузите в него содержимое этого архива.
2. В Render выберите создание Blueprint и подключите этот репозиторий.
3. Заполните значения `GOOGLE_WEB_CLIENT_ID`, `ADMIN_EMAILS` и при необходимости `OPENROUTER_API_KEY` в Environment.
4. Дождитесь успешного Deploy.
5. Проверьте `https://ВАШ-СЕРВИС.onrender.com/health` — должен вернуться JSON с `ok: true`.
6. Только после этого используйте URL `https://ВАШ-СЕРВИС.onrender.com` в админке и Android-конфигурации.

Render — внешний хостинг, поэтому для публикации требуется авторизация владельца аккаунта. Сам ZIP не может создать хостинг-аккаунт или опубликовать сервер автоматически.

## Проверки исходного кода
Запуск локальных тестов:
`node quota.test.mjs && node auth.test.mjs && node server.test.mjs`
